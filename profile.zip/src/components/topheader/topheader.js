import React, { Component } from 'react';
import '../topheader/topheader.css';

export default class topheader extends Component {
  render() {
    return (
      <div>
      <div className="header">
      <a href="#default" className="logo">Profile</a>
      <div className="header-right">
        <a ><img src={"https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1001.jpeg"} alt="" /></a>
        <a href="#about">Akash</a>
      </div>
    </div>
      </div>
    )
  }
}
