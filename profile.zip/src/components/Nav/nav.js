import React, { Component } from 'react';
import './nav.css';
import {Link}  from 'react-router-dom'

export default class Nav extends Component {
    render() {
        return (
            <div>
           <section className="menu_ul">  
            <ul>
              <li className="icon fa fa-home"> <Link to="/profile">Profile</Link></li>
              <li className="icon fa fa-keyboard-o"><Link to="/post">Post</Link></li>
              <li className="icon fa fa-coffee"><Link to="/gallery">Gallery</Link></li>
              <li className="icon fa fa-dribbble"><Link to="/todo">ToDo</Link></li>
            </ul>
           </section>
            </div>
        )
    }
}
