import React from 'react';
import logo from './logo.svg';
import './App.css';
import HomeIndex from './views/Home';
import ProfileIndex from './views/Profile';
import PostIndex from './views/Post';
import GalleryIndex from './views/Gallery';
import ToDoIndex from './views/Todo';
import { BrowserRouter, Route } from 'react-router-dom';

function App() {
  return (
    <div className="App">
    <BrowserRouter>
    <Route exact path="/" component={HomeIndex} />
    <Route exact path="/profile/:userId" component={ProfileIndex} />
    <Route exact path="/post" component={PostIndex} />
    <Route exact path="/gallery" component={GalleryIndex} />
    <Route exact path="/todo" component={ToDoIndex} />
    </BrowserRouter>
    </div>
  );
}

export default App;
