import ApiWrapper from "../../../shared/ApiWrapper"

class HomeService {

    userdetails(){
       return console.log("Home Service");
        // ApiWrapper.get("api/users.json", {})
    }
}

export default HomeService