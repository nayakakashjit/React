import React, { Component } from 'react';
import '../Home/index.css';
import axios from 'axios';
import {Link}  from 'react-router-dom'

export default class HomeIndex extends Component {
    state = {
        users: []
      }


      async componentDidMount(){
           axios.get(`https://panorbit.in/api/users.json`).then((response) =>{
            const users = response.data.users;
            this.setState({users})
        })
        .catch((err) => {
               console.log(err)
           })
    }
    
    render() {
        const userList = this.state.users.map(user => 
            <Link key={user.id} to={`/profile/${user.id}`}> 
            <li><span><img alt="timer" src={user.profilepicture} /></span> {user.name} </li>
            </Link>
            )
        return (
            <div>
            <header className="wave-bottom">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-xl-3"></div>
                            <div className="col-xl-6">
                            <div className="card">
                            <div className="card-header">Select an account</div>
                            <div className="card-body">
                            <ul className="list">
                            {
                                userList
                            }  
                          </ul>  
                            </div>
                            </div>
                            </div>
                        <div className="col-xl-3"></div>
                    </div>
                </div>
            </header>
            </div>
        )
    }
}
