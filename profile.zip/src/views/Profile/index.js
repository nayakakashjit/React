import React, { Component } from 'react';
import Nav from '../../components/Nav/nav'
import Profile from './profile';
import ProfileMap from './profileMap';
import Topheader from '../../components/topheader/topheader';
import axios from 'axios';

export default class ProfileIndex extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
            user: []
        }
    }
    
    componentDidMount(){
        const { match: { params } } = this.props;
        console.log(params.userId);

        axios.get(`https://panorbit.in/api/users.json`).then((response) =>{
            const user = response.data.users.filter((element) =>{
                return element.id == params.userId;
            })
            console.log(user);
            this.setState({user})
        })
        .catch((err) => {
               console.log(err)
           })
        
    }

    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-3"> <Nav /> </div>
                        <div className="col-md-9">
                            <Topheader />
                            <div className="row">
                                <div className="col-md-4"> <Profile userinfo = {this.state.user} /></div>
                                <div className="col-md-8"> <ProfileMap /> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
