import React, { Component } from 'react';
import './profileMap.css'

export default class profileMap extends Component {
    render() {
        return (
            <div>
               <div className="map">
                    <h5>Address:</h5>
                    <div className="mapinfo">
                    <div>
                       <p className="maptitle"> Street </p>
                    </div>
                    <div>
                       <p> : </p>
                    </div>
                    <div>
                       <p> Sholingnallur </p>
                    </div>
                 </div>
               </div>
               <div className="mapinfo">
               <div>
                  <p className="maptitle"> Suite </p>
               </div>
               <div>
                  <p> : </p>
               </div>
               <div>
                  <p> Apt.556 </p>
               </div>
            </div>
            <div className="mapinfo">
            <div>
               <p className="maptitle"> City </p>
            </div>
            <div>
               <p> : </p>
            </div>
            <div>
               <p> Bangalore </p>
            </div>
         </div>
         <div className="mapinfo">
         <div>
            <p className="maptitle"> Zipcode </p>
         </div>
         <div>
            <p> : </p>
         </div>
         <div>
            <p> 560037 </p>
         </div>
      </div>
      <div>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.2250367548277!2d77.71570921374907!3d13.021336617310633!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae104b9ee7dffb%3A0x45dd33efd8640ae8!2sMKB%20Friends%20Nest!5e0!3m2!1sen!2sin!4v1593951067859!5m2!1sen!2sin" width="600" height="450"  aria-hidden="false"></iframe>
      </div> 
            </div>
        )
    }
}
