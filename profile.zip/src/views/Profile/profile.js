import React, { Component } from 'react';
import './profile.css'

export default class profile extends Component {
   
   constructor(props) {
      super(props)
      console.log(this.props);
      this.state = {
          
      }
   }
   
   
    render() {
        return (
            <div>
            <div className="card pro-card">
            <img src={"https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1001.jpeg"} alt="" />
            <h5>Akash</h5>
            <div className="userinfo">
               <div>
                  <p className="title"> User Name </p>
               </div>
               <div>
                  <p> : </p>
               </div>
               <div>
                  <p> Akash@clo </p>
               </div>
            </div>
            <div className="userinfo">
               <div>
                  <p className="title"> E-mail </p>
               </div>
               <div>
                  <p> : </p>
               </div>
               <div>
                  <p> akashjit@gmail.com </p>
               </div>
            </div>
            <div className="userinfo">
               <div>
                  <p className="title"> Phone </p>
               </div>
               <div>
                  <p> : </p>
               </div>
               <div>
                  <p> 9439744847 </p>
               </div>
            </div>
            <div className="userinfo">
               <div>
                  <p className="title"> Website </p>
               </div>
               <div>
                  <p> : </p>
               </div>
               <div>
                  <p> padholeekho.com </p>
               </div>
            </div>
         </div>
         <hr/>
         <div className="userinfo">
         <div>
            <p className="title"> Name </p>
         </div>
         <div>
            <p> : </p>
         </div>
         <div>
            <p> Akashjit Nayak </p>
         </div>
      </div>

      <div className="userinfo">
      <div>
         <p className="title"> Catchphrase </p>
      </div>
      <div>
         <p> : </p>
      </div>
      <div>
         <p> Lorem ipsum Lorem </p>
      </div>
   </div>

   <div className="userinfo">
   <div>
      <p className="title"> bs </p>
   </div>
   <div>
      <p> : </p>
   </div>
   <div>
      <p> Lorem ipsum Lorem </p>
   </div>
</div>
            </div>
        )
    }
}
