import React, { Component } from 'react';
import Nav from '../../components/Nav/nav'

export default class ToDoIndex extends Component {
    render() {
        return (
            <div>
            <div className="container-fluid">
            <div className="row">
            <div className="col-md-3">
             <Nav />
            </div>
            <div className="col-md-9">
            <h1>To Do</h1>
            </div>
            </div>
            </div>
            </div>
        )
    }
}
