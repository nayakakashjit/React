import Axios from "axios";

export function getProfiles(){

    return axios.get();
}