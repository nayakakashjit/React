import axios from "axios";

class ApiWrapper {
    base_url = "https://panorbit.in/";

    get(path, params) {
        return axios.get(`${this.base_url}`+path, params);
      }

    put(path, params){
        return axios.put(`${this.base_url}`+path, params) 
    }

    post(path, params){
        return axios.post(`${this.base_url}`+path, params)
    }

    delete(path){
        return axios.delete(`${this.base_url}`+path)
    }
}

export default ApiWrapper;