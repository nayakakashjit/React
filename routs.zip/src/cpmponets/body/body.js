import React, { Component } from 'react';
import "../body/body.css";

class body extends Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      checkValue: false,
    };
  }

  inputHandler = (event) => {
    let inputField = event.target.name;
    let inputValue = event.target.value;
    let isChecked = event.target.checked;
    // let inputValue = input.type === 'checkbox' ? event.target.checked : event.target.value;
    this.setState({[inputField]: inputValue})
  }

  submitHandler = (event) => {
    event.preventDefault()
    let obj = {
      name: this.state.username,
      password: this.state.password,
      checkValue: this.state.checkValue

    }
    console.log(obj);
  }

    render() {
        return (
            <div>
                <div className="wrapper">
                    <div className="container">
                    <div className="col-left">
                        <div className="login-text">
                            <h2>Welcome</h2>
                            <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget eros dapibus, ultricies tellus vitae, consectetur tortor. Etiam rutrum placerat
                            </p>
                            <a className="btn" href="">Read More</a>
                        </div>
                        </div>
                        <div className="col-right">
      <div className="login-form">
        <h2>Login</h2>
        <form onSubmit={this.submitHandler}>
          <p>
            <input type="text" name="username" placeholder="Username" onChange={this.inputHandler} />
          </p>
          <p>
            <input type="password" name="password" placeholder="Password" onChange={this.inputHandler} />
          </p>
            <p> <input className="check_box" name="remeber"  checked={this.state.checkValue} onChange={this.inputHandler} type="checkbox" />Remeber Me</p>
          <p>
            <input className="btn"  type="submit" value="Sing In" />
          </p>
          <p>
            <a href="">Forget password?</a>
            <a href="">Create an account.</a>
          </p>
        </form>
      </div>
    </div>
  </div>
                    </div>
                </div>
        );
    }
}

export default body;