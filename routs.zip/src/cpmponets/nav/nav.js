import React, { Component } from 'react';
import "../nav/nav.css" 

class nav extends Component {
    render() {
        return (
            <div>
                <nav>
                <div class="desktop-nav-container">
                    <span class="nav-brand">React Class</span>
                    <div class="nav-menu-container">
                    <span class="nav-menu-item">Home</span>
                    <span class="nav-menu-item">Services</span>
                    <span class="nav-menu-item">Blog</span>
                    <span class="nav-menu-item">About</span>
                    <span class="nav-menu-item">Contact</span>
                    </div>
                </div>
                </nav>
            </div>
        );
    }
}

export default nav;