import React, { Component } from 'react';
import "../footer/footer.css"

class footer extends Component {
    render() {
        return (
            <div>
                <div class="footer">
                    <p>All right received ©2020 React Class.Sanjy Pvt Ltd.</p>
                </div>
            </div>
        );
    }
}

export default footer;